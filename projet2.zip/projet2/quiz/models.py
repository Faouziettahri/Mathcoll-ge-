from django.db import models

class QuizResult(models.Model):
    NIVEAU_CHOICES = [
        ('1AC', '1ère année collège (1AC)'),
        ('2AC', '2ème année collège (2AC)'),
        ('3AC', '3ème année collège (3AC)'),
    ]
    name = models.CharField(max_length=100, verbose_name="Nom complet")
    niveau = models.CharField(max_length=3, choices=NIVEAU_CHOICES, verbose_name="Niveau scolaire")
    course = models.CharField(max_length=200, verbose_name="Groupe de QCM")
    score = models.IntegerField(verbose_name="Score obtenu")
    total_questions = models.IntegerField(default=0, verbose_name="Nombre total de questions")
    time_spent = models.IntegerField(verbose_name="Temps passé (secondes)")
    date = models.DateTimeField(auto_now_add=True, verbose_name="Date et heure")
    student_image = models.ImageField(upload_to='students/', blank=True, null=True, verbose_name="Photo")

    class Meta:
        verbose_name = "Résultat de quiz"
        verbose_name_plural = "Résultats des quiz"
        ordering = ['-date']

    def moyenne(self):
        """Retourne la moyenne en pourcentage"""
        if self.total_questions > 0:
            return f"{(self.score / self.total_questions * 100):.1f}%"
        return "0%"

    moyenne.short_description = "Moyenne"

    def __str__(self):
        return f"{self.name} – {self.course} ({self.score}/{self.total_questions})"