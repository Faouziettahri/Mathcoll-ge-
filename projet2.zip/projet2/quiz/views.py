import json
import base64
from datetime import datetime
from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.core.files.base import ContentFile
from .models import QuizResult

def index(request):
    """الصفحة الرئيسية للعبة"""
    return render(request, 'quiz/index.html')

@csrf_exempt
def save_result(request):
    """حفظ نتيجة الطالب المرسلة عبر POST"""
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            quiz_result = QuizResult(
                name=data['name'],
                niveau=data['niveau'],
                course=data['course'],
                score=data['score'],
                total_questions=data['totalQuestions'],
                time_spent=data['time'],
            )
            # معالجة الصورة إذا كانت مرسلة كـ base64
            if data.get('photo'):
                format, imgstr = data['photo'].split(';base64,')
                ext = format.split('/')[-1]
                photo_data = ContentFile(
                    base64.b64decode(imgstr),
                    name=f"{data['name']}_{datetime.now().strftime('%Y%m%d%H%M%S')}.{ext}"
                )
                quiz_result.student_image.save(photo_data.name, photo_data, save=False)
            quiz_result.save()
            return JsonResponse({'success': True, 'id': quiz_result.id})
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)}, status=400)
    return JsonResponse({'success': False, 'error': 'Méthode non autorisée'}, status=405)