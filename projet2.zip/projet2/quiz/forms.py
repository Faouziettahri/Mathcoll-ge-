from django import forms

class MonForm(forms.Form):
    nom = forms.CharField(max_length=100)
    email = forms.EmailField()