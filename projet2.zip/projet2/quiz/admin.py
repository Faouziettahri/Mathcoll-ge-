from django.contrib import admin
from django.utils.html import format_html
from .models import QuizResult

@admin.register(QuizResult)
class QuizResultAdmin(admin.ModelAdmin):
    list_display = ['student_image_preview', 'name', 'niveau', 'course', 'score', 'total_questions', 'moyenne', 'time_spent', 'date']
    list_filter = ['niveau', 'course', 'date']
    search_fields = ['name', 'course']
    readonly_fields = ['student_image_preview', 'date']
    fieldsets = (
        ('معلومات التلميذ', {'fields': ('name', 'niveau', 'student_image')}),
        ('نتيجة الاختبار', {'fields': ('course', 'score', 'total_questions', 'time_spent', 'date')}),
    )

    def student_image_preview(self, obj):
        if obj.student_image:
            return format_html('<img src="{}" style="width: 50px; height: 50px; border-radius: 50%; object-fit: cover;" />', obj.student_image.url)
        return "لا توجد صورة"

    student_image_preview.short_description = "صورة"